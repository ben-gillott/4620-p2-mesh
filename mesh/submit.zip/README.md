CS 4620 Assignment 2 - Mesh
Authors: Pippen Wu (hw473), Benjamin Gillott (bg357)

Current Issues:

We are aware of some sphere UV mapping issues: The rotation of the globe is different from the provided reference, and the mapping at the very southern pole (where m = divisionsV) is wrong.


Extra Credit:

advanceCompare (10pt)
Completed the compare function in O(n) time. Light proof is in code comments.
